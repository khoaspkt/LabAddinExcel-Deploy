@echo off
setlocal EnableExtensions EnableDelayedExpansion

title LabAddinExcel - Cai dat va thiet lap tin cay

set "APP_NAME=LabAddinExcel"
set "BASE_URL=https://khoaspkt.github.io/LabAddinExcel-Deploy"
set "SITE_HOST=khoaspkt.github.io"
set "SETUP_URL=%BASE_URL%/setup.exe"
set "VSTO_URL=%BASE_URL%/LabAddinExcel.vsto"
set "WORK_DIR=%TEMP%\LabAddinExcelInstall"
set "SETUP_FILE=%WORK_DIR%\setup.exe"

echo ============================================================
echo  LABADDINEXCEL - CAI DAT ADD-IN EXCEL
echo ============================================================
echo.
echo  Trang cai dat : %BASE_URL%
echo  File setup    : %SETUP_URL%
echo.

REM ============================================================
REM 1. Them GitHub Pages vao Trusted Sites cua user hien tai
REM Zone ID:
REM 0 = My Computer
REM 1 = Local Intranet
REM 2 = Trusted Sites
REM 3 = Internet
REM 4 = Restricted Sites
REM ============================================================

echo [1/6] Dang them %SITE_HOST% vao Trusted Sites...

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\github.io\khoaspkt" /v https /t REG_DWORD /d 2 /f >nul 2>&1

if errorlevel 1 (
    echo      Loi: Khong the them Trusted Sites vao HKCU.
) else (
    echo      OK: Da them https://%SITE_HOST% vao Trusted Sites.
)

REM ============================================================
REM 2. Cau hinh ClickOnce trust prompt neu co quyen Administrator
REM Microsoft dung key nay de dieu khien viec hien trust prompt.
REM HKLM can quyen Administrator. Neu khong co quyen, bo qua.
REM ============================================================

echo.
echo [2/6] Dang cau hinh ClickOnce/VSTO trust prompt neu co quyen...

reg add "HKLM\SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v MyComputer /t REG_SZ /d Enabled /f >nul 2>&1
if errorlevel 1 (
    echo      Khong co quyen Administrator hoac bi chan policy. Bo qua HKLM.
    echo      Ghi chu: Neu van cai duoc thi khong can chay lai bang Admin.
) else (
    reg add "HKLM\SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v LocalIntranet /t REG_SZ /d Enabled /f >nul 2>&1
    reg add "HKLM\SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v TrustedSites /t REG_SZ /d Enabled /f >nul 2>&1
    reg add "HKLM\SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v Internet /t REG_SZ /d AuthenticodeRequired /f >nul 2>&1
    reg add "HKLM\SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v UntrustedSites /t REG_SZ /d Disabled /f >nul 2>&1

    REM Them ca nhanh WOW6432Node de tang tuong thich may Office/Runtime 32-bit
    reg add "HKLM\SOFTWARE\WOW6432Node\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v MyComputer /t REG_SZ /d Enabled /f >nul 2>&1
    reg add "HKLM\SOFTWARE\WOW6432Node\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v LocalIntranet /t REG_SZ /d Enabled /f >nul 2>&1
    reg add "HKLM\SOFTWARE\WOW6432Node\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v TrustedSites /t REG_SZ /d Enabled /f >nul 2>&1
    reg add "HKLM\SOFTWARE\WOW6432Node\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v Internet /t REG_SZ /d AuthenticodeRequired /f >nul 2>&1
    reg add "HKLM\SOFTWARE\WOW6432Node\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel" /v UntrustedSites /t REG_SZ /d Disabled /f >nul 2>&1

    echo      OK: Da cau hinh ClickOnce trust prompt.
)

REM ============================================================
REM 3. Kiem tra Excel dang mo
REM ============================================================

echo.
echo [3/6] Dang kiem tra Excel...

tasklist /FI "IMAGENAME eq EXCEL.EXE" 2>nul | find /I "EXCEL.EXE" >nul 2>&1

if not errorlevel 1 (
    echo      Excel dang mo.
    echo      Vui long LUU FILE, DONG EXCEL truoc khi cai add-in.
    echo.
    pause
)

REM ============================================================
REM 4. Tao thu muc tam va tai setup.exe
REM ============================================================

echo.
echo [4/6] Dang tai setup.exe moi nhat...

if not exist "%WORK_DIR%" mkdir "%WORK_DIR%" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "try { " ^
    "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " ^
    "$url = '%SETUP_URL%'; " ^
    "$out = '%SETUP_FILE%'; " ^
    "Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing; " ^
    "if (Test-Path $out) { Unblock-File -Path $out -ErrorAction SilentlyContinue; exit 0 } else { exit 2 } " ^
    "} catch { Write-Host $_.Exception.Message; exit 1 }"

if errorlevel 1 (
    echo.
    echo      Loi: Khong tai duoc setup.exe.
    echo      Hay kiem tra Internet hoac mo thu link:
    echo      %SETUP_URL%
    echo.
    pause
    exit /b 1
)

echo      OK: Da tai setup.exe ve:
echo      %SETUP_FILE%

REM ============================================================
REM 5. Chay setup.exe
REM ============================================================

echo.
echo [5/6] Dang chay bo cai LabAddinExcel...
echo.

start /wait "" "%SETUP_FILE%"

REM ============================================================
REM 6. Ket thuc
REM ============================================================

echo.
echo [6/6] Hoan tat tien trinh cai dat.
echo.
echo Neu cai dat thanh cong:
echo   - Mo Excel
echo   - Kiem tra tab LAB tren Ribbon
echo   - Neu chua co du lieu, bam nut Cap nhat du lieu trong add-in
echo.
echo Neu cai dat van bi chan:
echo   - Chay lai file nay bang Run as administrator
echo   - Hoac lien he nguoi quan tri may de mo ClickOnce/VSTO trust prompt
echo.

pause
exit /b 0